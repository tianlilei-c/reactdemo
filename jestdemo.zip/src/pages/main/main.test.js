import React from 'react';
import { render, fireEvent, waitFor, act, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import fetchMock from 'jest-fetch-mock';
import configureStore from 'redux-mock-store';
import { MemoryRouter } from 'react-router-dom'; // 导入MemoryRouter

import Main from './main.js';

const mockStore = configureStore([]);

describe('<Main />', () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      logindata: { username: 'Bret', address: { street: 'Kulas Light' } },
    });
    store.dispatch = jest.fn();
    fetchMock.resetMocks();
    const user = { username: 'Bret', email: 'testUser@test.com', phone: '123-456-7890', address: { street: 'Kulas Light', zipcode: '12345' } };
    localStorage.setItem('user', JSON.stringify(user));
  });

  afterEach(() => {
    localStorage.removeItem('user');
  });

  it('should set FollowedTrendsList with correct data', async () => {
    // 模拟 'https://jsonplaceholder.typicode.com/posts' 请求的响应
    const postData = [
      {
        "userId": 1,
        "id": 1,
        "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      },
      {
        "userId": 1,
        "id": 2,
        "title": "qui est esse",
        "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
      },
      {
        "userId": 1,
        "id": 3,
        "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
        "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
      },
      // ... 其他数据
    ];

    fetchMock.mockResponses(
      [JSON.stringify(postData), { status: 200 }],
      [JSON.stringify([{
        "id": 1,
        "name": "Leanne Graham",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "address": {
          "street": "Kulas Light",
          "suite": "Apt. 556",
          "city": "Gwenborough",
          "zipcode": "92998-3874",
          "geo": {
            "lat": "-37.3159",
            "lng": "81.1496"
          }
        },
        "phone": "1-770-736-8031 x56442",
        "website": "hildegard.org",
        "company": {
          "name": "Romaguera-Crona",
          "catchPhrase": "Multi-layered client-server neural-net",
          "bs": "harness real-time e-markets"
        }
      },
      {
        "id": 2,
        "name": "Ervin Howell",
        "username": "Antonette",
        "email": "Shanna@melissa.tv",
        "address": {
          "street": "Victor Plains",
          "suite": "Suite 879",
          "city": "Wisokyburgh",
          "zipcode": "90566-7771",
          "geo": {
            "lat": "-43.9509",
            "lng": "-34.4618"
          }
        },
        "phone": "010-692-6593 x09125",
        "website": "anastasia.net",
        "company": {
          "name": "Deckow-Crist",
          "catchPhrase": "Proactive didactic contingency",
          "bs": "synergize scalable supply-chains"
        }
      }]), { status: 200 }]
    );

    const { } = render(
      <Provider store={store}>
        <MemoryRouter>
          <Main />
        </MemoryRouter>
      </Provider>
    );
    // 使用 queryAllByText 方法获取所有包含文字 "Bret" 的元素
    const bretElements = screen.queryAllByText('Bret');
    // 断言至少有一个元素存在
    expect(bretElements.length).toBeGreaterThan(0);
  });

  it('should filter FollowedTrendsList based on search text', async () => {
    const postData = [
      {
        "userId": 1,
        "id": 1,
        "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      },
      {
        "userId": 1,
        "id": 2,
        "title": "qui est esse",
        "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
      },
      {
        "userId": 1,
        "id": 3,
        "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
        "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
      },
      // ... 其他数据
    ];

    fetchMock.mockResponses(
      [JSON.stringify(postData), { status: 200 }],
      [JSON.stringify([{
        "id": 1,
        "name": "Leanne Graham",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "address": {
          "street": "Kulas Light",
          "suite": "Apt. 556",
          "city": "Gwenborough",
          "zipcode": "92998-3874",
          "geo": {
            "lat": "-37.3159",
            "lng": "81.1496"
          }
        },
        "phone": "1-770-736-8031 x56442",
        "website": "hildegard.org",
        "company": {
          "name": "Romaguera-Crona",
          "catchPhrase": "Multi-layered client-server neural-net",
          "bs": "harness real-time e-markets"
        }
      },
      {
        "id": 2,
        "name": "Ervin Howell",
        "username": "Antonette",
        "email": "Shanna@melissa.tv",
        "address": {
          "street": "Victor Plains",
          "suite": "Suite 879",
          "city": "Wisokyburgh",
          "zipcode": "90566-7771",
          "geo": {
            "lat": "-43.9509",
            "lng": "-34.4618"
          }
        },
        "phone": "010-692-6593 x09125",
        "website": "anastasia.net",
        "company": {
          "name": "Deckow-Crist",
          "catchPhrase": "Proactive didactic contingency",
          "bs": "synergize scalable supply-chains"
        }
      }]), { status: 200 }]
    );

    render(
      <Provider store={store}>
        <MemoryRouter>
          <Main />
        </MemoryRouter>
      </Provider>
    );

    // 模拟输入搜索文本
    const searchText = 'xxxxxxxxx';
    const searchInput = screen.getByPlaceholderText('Search messages');
    fireEvent.change(searchInput, { target: { value: searchText } });
    const bretElements = screen.queryAllByText('Bret');
    expect(bretElements.length).toBe(1);
  });
  // it('delete followed', () => {
  //   const postData = [
  //     {
  //       "userId": 1,
  //       "id": 1,
  //       "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  //       "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
  //     },
  //     {
  //       "userId": 1,
  //       "id": 2,
  //       "title": "qui est esse",
  //       "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
  //     },
  //     {
  //       "userId": 1,
  //       "id": 3,
  //       "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
  //       "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
  //     },
  //     // ... 其他数据
  //   ];

  //   fetchMock.mockResponses(
  //     [JSON.stringify(postData), { status: 200 }],
  //     [JSON.stringify([{
  //       "id": 1,
  //       "name": "Leanne Graham",
  //       "username": "Bret",
  //       "email": "Sincere@april.biz",
  //       "address": {
  //         "street": "Kulas Light",
  //         "suite": "Apt. 556",
  //         "city": "Gwenborough",
  //         "zipcode": "92998-3874",
  //         "geo": {
  //           "lat": "-37.3159",
  //           "lng": "81.1496"
  //         }
  //       },
  //       "phone": "1-770-736-8031 x56442",
  //       "website": "hildegard.org",
  //       "company": {
  //         "name": "Romaguera-Crona",
  //         "catchPhrase": "Multi-layered client-server neural-net",
  //         "bs": "harness real-time e-markets"
  //       }
  //     },
  //     {
  //       "id": 2,
  //       "name": "Ervin Howell",
  //       "username": "Antonette",
  //       "email": "Shanna@melissa.tv",
  //       "address": {
  //         "street": "Victor Plains",
  //         "suite": "Suite 879",
  //         "city": "Wisokyburgh",
  //         "zipcode": "90566-7771",
  //         "geo": {
  //           "lat": "-43.9509",
  //           "lng": "-34.4618"
  //         }
  //       },
  //       "phone": "010-692-6593 x09125",
  //       "website": "anastasia.net",
  //       "company": {
  //         "name": "Deckow-Crist",
  //         "catchPhrase": "Proactive didactic contingency",
  //         "bs": "synergize scalable supply-chains"
  //       }
  //     }]), { status: 200 }]
  //   );

  //   render(
  //     <Provider store={store}>
  //       <MemoryRouter>
  //         <Main />
  //       </MemoryRouter>
  //     </Provider>
  //   );

  //   const unfollowButton = screen.getByText('unfollow');
  //   expect(unfollowButton).toBeInTheDocument();
  //   fireEvent.click(unfollowButton);
  // })

});
